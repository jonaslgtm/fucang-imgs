// 从URL中提取contentId
function getContentId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('contentId');
}

// 获取本地存储中的accessToken
function getAccessToken() {
    const authKey = Object.keys(localStorage).find(key => key.startsWith('ND_UC_AUTH'));
    if (!authKey) return null;
    
    try {
        const tokenData = JSON.parse(localStorage.getItem(authKey));
        return JSON.parse(tokenData.value).access_token;
    } catch (e) {
        console.error('解析token失败:', e);
        return null;
    }
}

// 创建下载按钮
function createDownloadButton(downloadUrl) {
    const button = document.createElement('button');
    button.id = '教材下载按钮';
    button.textContent = '下载教材';
    button.style.position = 'fixed';
    button.style.bottom = '20px';
    button.style.left = '20px';
    button.style.zIndex = '9999';
    button.style.padding = '10px 20px';
    button.style.backgroundColor = '#007bff';
    button.style.color = 'white';
    button.style.border = 'none';
    button.style.borderRadius = '5px';
    button.style.cursor = 'pointer';
    
    button.addEventListener('click', () => {
        window.open(downloadUrl, '_blank');
    });
    
    return button;
}

// 主逻辑 - 页面加载时仅创建按钮
function init() {
    const contentId = getContentId();
    if (!contentId) {
        console.log('未找到contentId');
        return;
    }
    
    // 创建并添加下载按钮（初始状态）
    const button = createDownloadButton();
    document.body.appendChild(button);
}

// 点击按钮后执行下载逻辑
async function handleDownload() {
    const button = document.getElementById('教材下载按钮');
    button.disabled = true;
    button.textContent = '处理中...';
    
    try {
        const contentId = getContentId();
        const accessToken = getAccessToken();
        
        if (!accessToken) {
            throw new Error('未找到访问令牌，请确保已登录国家中小学智慧教育平台');
        }
        
        // 获取教材下载信息
        const response = await fetch(`https://s-file-2.ykt.cbern.com.cn/zxx/ndrv2/resources/tch_material/details/${contentId}.json`);
        if (!response.ok) {
            throw new Error(`API请求失败: ${response.status}`);
        }
        
        const data = await response.json();
        
        // 从ti_items中查找包含PDF的存储信息
        console.log('API响应数据:', data);
        
        // 查找ti_file_flag为source的项，它包含原始PDF文件
        const sourceItem = data.ti_items?.find(item => item.ti_file_flag === 'source');
        if (!sourceItem || !sourceItem.ti_storages || !Array.isArray(sourceItem.ti_storages)) {
            console.error('未找到有效的源文件存储信息:', data.ti_items);
            throw new Error('未找到有效的教材存储信息，请检查API响应结构。详情请查看浏览器控制台。');
        }

        // 优化的URL提取算法 - 直接从ti_storages数组获取完整URL
        console.log('ti_storages内容:', sourceItem.ti_storages);
        
        // 从ti_storages数组中直接获取PDF URL（URL已经是完整的）
        const pdfUrl = sourceItem.ti_storages
            .find(url => {
                // 检查URL是否为字符串且包含PDF文件
                if (typeof url === 'string' && url.toLowerCase().includes('.pdf')) {
                    console.log('找到PDF URL:', url);
                    return true;
                }
                return false;
            });

        if (!pdfUrl) {
            console.error('未找到有效的PDF链接，ti_storages内容:', sourceItem.ti_storages);
            throw new Error('未找到有效的PDF下载链接，请检查ti_storages数组内容');
        }

        // 编码URL（保留已存在的编码字符）
        const encodedPdfUrl = encodeURI(pdfUrl);

        // 构建下载链接并打开
        const downloadUrl = `${encodedPdfUrl}?accessToken=${accessToken}`;
        window.open(downloadUrl, '_blank');
        
        button.textContent = '下载成功';
        setTimeout(() => {
            button.textContent = '下载教材';
            button.disabled = false;
        }, 2000);
    } catch (e) {
        console.error('下载链接获取失败:', e);
        alert(`获取下载链接失败: ${e.message}`);
        button.textContent = '下载教材';
        button.disabled = false;
    }
}

// 更新按钮创建函数
function createDownloadButton() {
    const button = document.createElement('button');
    button.id = '教材下载按钮';
    button.textContent = '下载教材';
    button.style.position = 'fixed';
    button.style.top = '20px';
    button.style.right = '20px';
    button.style.zIndex = '9999';
    button.style.padding = '10px 20px';
    button.style.backgroundColor = '#26aaebff';
    button.style.color = 'white';
    button.style.border = 'none';
    button.style.borderRadius = '5px';
    button.style.cursor = 'pointer';
    
    button.addEventListener('click', handleDownload);
    
    return button;
}

// 页面加载完成后执行
window.addEventListener('load', init);
